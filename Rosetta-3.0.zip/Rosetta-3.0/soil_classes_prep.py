# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 13:15:55 2019

@author: Alexander
"""

# true when writing out from dict to np txt file
# false when loading np txt output back into dict

write_or_load_switch = False

texture_rules = {
    # l - liiv, en: sand
    'l': {'sand': 90, 'silt': 5, 'clay': 5, 'lxtype': 'S'},
    'l1': {'sand': 95, 'silt': 5, 'clay': 0, 'lxtype': 'S'},
    'l2': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},
    'l3': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},
    'l4': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},
    'l5': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},
    # pl - peenliiv, en: fine sand (täiendina peenliivakas)
    'pl': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},

    # plsl - peenliivakas saviliiv, en: fine clayey sand
    'plsl': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    # sl - saviliiv, en: clayey sand
    'sl': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    'sl1': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    'sl2': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    'sl3': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    'sl4': {'sand': 82, 'silt': 9, 'clay': 9, 'lxtype': 'LS'},
    # tsl - tolmjas saviliiv, en: dusty clayey sand
    'tsl': {'sand': 80, 'silt': 14, 'clay': 6, 'lxtype': 'LS'},
    'tsl1': {'sand': 80, 'silt': 14, 'clay': 6, 'lxtype': 'LS'},
    # dk - liivakivirähk, en: sandstone grit
    'dk': {'sand': 90, 'silt': 3, 'clay': 7, 'lxtype': 'S'},

    # ls - liivsavi
    'ls': {'sand': 55, 'silt': 30, 'clay': 15, 'lxtype': 'L'},
    #   ls₁ - kerge liivsavi, en: light sandy clay
    'ls1': {'sand': 65, 'silt': 20, 'clay': 15, 'lxtype': 'SL'},
    #   ls₂ - keskmine liivsavi, en: medium sandy clay
    'ls2': {'sand': 55, 'silt': 30, 'clay': 15, 'lxtype': 'L'},
    #   ls₃ - raske liivsavi, en: heavy sandy clay
    'ls3': {'sand': 50, 'silt': 15, 'clay': 35, 'lxtype': 'CL'},
    'ls4': {'sand': 50, 'silt': 15, 'clay': 35, 'lxtype': 'CL'},
    'ls5': {'sand': 50, 'silt': 15, 'clay': 35, 'lxtype': 'CL'},

    # tls - tolmjas liivsavi, en: dusty sandy clay
    'tls': {'sand': 35, 'silt': 50, 'clay': 15, 'lxtype': 'SiL'},
    'tls1': {'sand': 40, 'silt': 45, 'clay': 15, 'lxtype': 'L'},
    'tls2': {'sand': 35, 'silt': 50, 'clay': 15, 'lxtype': 'SiL'},
    'tls3': {'sand': 30, 'silt': 40, 'clay': 30, 'lxtype': 'SiCL'},
    # s - savi, en: clay
    's': {'sand': 25, 'silt': 30, 'clay': 45, 'lxtype': 'C'},
    's1': {'sand': 25, 'silt': 30, 'clay': 45, 'lxtype': 'C'},
    's2': {'sand': 25, 'silt': 30, 'clay': 45, 'lxtype': 'HC'},

    # th 15 või th 15-20 toorhuumusliku horisondi tüsedus, en: raw humus thickness
    'th': {'sand': 25, 'silt': 25, 'clay': 50, 'lxtype': 'HUMUS'},
    'th3': {'sand': 25, 'silt': 25, 'clay': 50, 'lxtype': 'HUMUS'},

    # t - turvas, en: peat, amp is erodeeritud level
    't': {'sand': 25, 'silt': 25, 'clay': 50, 'lxtype': 'PEAT'},
    #   t₁ - halvasti lagunenud, en: (under 20%)
    't1': {'sand': 25, 'silt': 25, 'clay': 50, 'lxtype': 'PEAT'},
    #   t₂ - keskmine lagunenud, en: (20%-40%)
    't2': {'sand': 20, 'silt': 20, 'clay': 60, 'lxtype': 'PEAT'},
    #   t₃ - hästi lagunenud, en: (above 40%)
    't3': {'sand': 15, 'silt': 15, 'clay': 70, 'lxtype': 'PEAT'},

    # all rocky
    # def skeleton_no_amp(): return [  no_info, pk, kr, p, d, lu, ck ]

    # r 2 rähk             'r', 'r1', 'r2', 'r3', 'r4', 'r5', 'r⁰', 'r⁰1',
    # v 3 paeveeris        'v', 'v1', 'v2', 'v3', 'v4', 'v5'
    # v_0 4 raudkiviveeris 'v_0', 'v°1', 'v⁰', 'v⁰1', 'v⁰2', 'v⁰4'
    # kb 5 klibu           'kb', 'kb1', 'kb2', 'kb3', 'kb4', 'kb5'

    # k 7 paekivid         'k', 'k1', 'k2', 'k3', 'k4', 'k5'
    # k_0 8 raudkivid      'k_0', 'k°1', 'k⁰', 'k⁰1', 'k⁰2', 'k⁰3', 'k⁰5'

    # kr 1 kruus (no_amp?) 'kr', 'kr1', 'kr5'

    # ck 6 kiltkivirähk (no_amp?) 'ck'

    # pk 9 paeplaadid (no_amp?)  'pk'
    # p 10 paas    (no_amp?)     'p'
    # d 11 liivakivi (no_amp?)   'd'
    # lu 12 lubisetted (no_amp?) 'lu'

    # Mahuprotsente ei kasutata korese tüüp 1, 9, 10, 11, ja 12 puhul   #
    'ck': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'd': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'lu': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'p': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'pk': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kr': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kr1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kr5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},

    'k': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k_0': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'kb5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k°1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'k⁰5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'r⁰5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v_0': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v°1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰1': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰2': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰3': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰4': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},
    'v⁰5': {'sand': 100, 'silt': 0, 'clay': 0, 'lxtype': 'GRAVELS'},

    # NaN 0
    'no_peenes': {'sand': 60, 'silt': 20, 'clay': 20, 'lxtype': 'no_info'},
    'no_info': {'sand': 60, 'silt': 20, 'clay': 20, 'lxtype': 'no_info'}
}

import numpy as np
import math

s1 = len(texture_rules.keys())

arr = np.zeros((s1,3), dtype=float)

counter = 0

for k in texture_rules.keys():
    print(k)
    # print(texture_rules[k]['sand'])
    sa = texture_rules[k]['sand']
    sl = texture_rules[k]['silt']
    cl = texture_rules[k]['clay']
    
    arr[counter][0] = float(sa)
    arr[counter][1] = float(sl)
    arr[counter][2] = float(cl)
    counter = counter+1


if write_or_load_switch == True:
    np.savetxt("soil_classes_inp_mod2.txt", arr)
    print(arr)
else:
    n_arr = np.loadtxt("soil_classes_output_mod2.txt", delimiter=",")
    counter = 0
    
    for k in texture_rules.keys():
        print(k)
        k_val_cm_d = n_arr[counter][4]
        k_val = k_val_cm_d * 10 / 24
        texture_rules[k]['k_sat'] = np.round(k_val, 2)
        counter = counter+1
        
print(texture_rules)

        