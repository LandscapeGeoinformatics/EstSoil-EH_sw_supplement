Rosetta 3 program:

- only worked on Python 2.7, conda environment requirements.txt included in Rosetta-3.0 folder/zip

How to use:

- edit Rpredict.py to select model (SSC or includong bulk density)
- create input file that can be read by numpy, like in "soil_classes_prep.py"
- run like documented in "run_Rosetta.sh"
- load the produced output into your data structure

Citation:

Zhao, H., Zeng, Y., Lv, S. and Su, Z.: Analysis of soil hydraulic and thermal properties for land surface modeling over the Tibetan Plateau,
Earth Syst. Sci. Data, 10(2), 1031–1061, doi:10.5194/essd-10-1031-2018, 2018.